void myregfree(void *);

