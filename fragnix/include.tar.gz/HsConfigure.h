#define HAS_DataPico 0
#if LANGUAGE_Rank2Types
#if MIN_VERSION_base(4,2,0)
#undef HAS_DataPico
#define HAS_DataPico 1
#endif
#endif
