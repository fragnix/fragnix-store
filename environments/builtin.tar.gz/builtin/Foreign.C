[
    {
        "name": "CChar",
        "module": "Foreign.C.Types",
        "type": "CChar",
        "entity": "constructor"
    },
    {
        "name": "CClock",
        "module": "Foreign.C.Types",
        "type": "CClock",
        "entity": "constructor"
    },
    {
        "name": "CDouble",
        "module": "Foreign.C.Types",
        "type": "CDouble",
        "entity": "constructor"
    },
    {
        "name": "CFloat",
        "module": "Foreign.C.Types",
        "type": "CFloat",
        "entity": "constructor"
    },
    {
        "name": "CInt",
        "module": "Foreign.C.Types",
        "type": "CInt",
        "entity": "constructor"
    },
    {
        "name": "CIntMax",
        "module": "Foreign.C.Types",
        "type": "CIntMax",
        "entity": "constructor"
    },
    {
        "name": "CIntPtr",
        "module": "Foreign.C.Types",
        "type": "CIntPtr",
        "entity": "constructor"
    },
    {
        "name": "CLLong",
        "module": "Foreign.C.Types",
        "type": "CLLong",
        "entity": "constructor"
    },
    {
        "name": "CLong",
        "module": "Foreign.C.Types",
        "type": "CLong",
        "entity": "constructor"
    },
    {
        "name": "CPtrdiff",
        "module": "Foreign.C.Types",
        "type": "CPtrdiff",
        "entity": "constructor"
    },
    {
        "name": "CSChar",
        "module": "Foreign.C.Types",
        "type": "CSChar",
        "entity": "constructor"
    },
    {
        "name": "CSUSeconds",
        "module": "Foreign.C.Types",
        "type": "CSUSeconds",
        "entity": "constructor"
    },
    {
        "name": "CShort",
        "module": "Foreign.C.Types",
        "type": "CShort",
        "entity": "constructor"
    },
    {
        "name": "CSigAtomic",
        "module": "Foreign.C.Types",
        "type": "CSigAtomic",
        "entity": "constructor"
    },
    {
        "name": "CSize",
        "module": "Foreign.C.Types",
        "type": "CSize",
        "entity": "constructor"
    },
    {
        "name": "CTime",
        "module": "Foreign.C.Types",
        "type": "CTime",
        "entity": "constructor"
    },
    {
        "name": "CUChar",
        "module": "Foreign.C.Types",
        "type": "CUChar",
        "entity": "constructor"
    },
    {
        "name": "CUInt",
        "module": "Foreign.C.Types",
        "type": "CUInt",
        "entity": "constructor"
    },
    {
        "name": "CUIntMax",
        "module": "Foreign.C.Types",
        "type": "CUIntMax",
        "entity": "constructor"
    },
    {
        "name": "CUIntPtr",
        "module": "Foreign.C.Types",
        "type": "CUIntPtr",
        "entity": "constructor"
    },
    {
        "name": "CULLong",
        "module": "Foreign.C.Types",
        "type": "CULLong",
        "entity": "constructor"
    },
    {
        "name": "CULong",
        "module": "Foreign.C.Types",
        "type": "CULong",
        "entity": "constructor"
    },
    {
        "name": "CUSeconds",
        "module": "Foreign.C.Types",
        "type": "CUSeconds",
        "entity": "constructor"
    },
    {
        "name": "CUShort",
        "module": "Foreign.C.Types",
        "type": "CUShort",
        "entity": "constructor"
    },
    {
        "name": "CWchar",
        "module": "Foreign.C.Types",
        "type": "CWchar",
        "entity": "constructor"
    },
    {
        "name": "CFile",
        "module": "Foreign.C.Types",
        "entity": "data"
    },
    {
        "name": "CFpos",
        "module": "Foreign.C.Types",
        "entity": "data"
    },
    {
        "name": "CJmpBuf",
        "module": "Foreign.C.Types",
        "entity": "data"
    },
    {
        "name": "CChar",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CClock",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CDouble",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CFloat",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CInt",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CIntMax",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CIntPtr",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CLLong",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CLong",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CPtrdiff",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CSChar",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CSUSeconds",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CShort",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CSigAtomic",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CSize",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CTime",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CUChar",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CUInt",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CUIntMax",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CUIntPtr",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CULLong",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CULong",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CUSeconds",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CUShort",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "CWchar",
        "module": "Foreign.C.Types",
        "entity": "newtype"
    },
    {
        "name": "castCCharToChar",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "castCSCharToChar",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "castCUCharToChar",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "castCharToCChar",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "castCharToCSChar",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "castCharToCUChar",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "charIsRepresentable",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "newCAString",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "newCAStringLen",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "newCString",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "newCStringLen",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "newCWString",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "newCWStringLen",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "peekCAString",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "peekCAStringLen",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "peekCString",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "peekCStringLen",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "peekCWString",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "peekCWStringLen",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "withCAString",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "withCAStringLen",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "withCString",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "withCStringLen",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "withCWString",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "withCWStringLen",
        "module": "Foreign.C.String",
        "entity": "value"
    },
    {
        "name": "CString",
        "module": "Foreign.C.String",
        "entity": "type"
    },
    {
        "name": "CStringLen",
        "module": "Foreign.C.String",
        "entity": "type"
    },
    {
        "name": "CWString",
        "module": "Foreign.C.String",
        "entity": "type"
    },
    {
        "name": "CWStringLen",
        "module": "Foreign.C.String",
        "entity": "type"
    },
    {
        "name": "e2BIG",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eACCES",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eADDRINUSE",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eADDRNOTAVAIL",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eADV",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eAFNOSUPPORT",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eAGAIN",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eALREADY",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eBADF",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eBADMSG",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eBADRPC",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eBUSY",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eCHILD",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eCOMM",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eCONNABORTED",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eCONNREFUSED",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eCONNRESET",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eDEADLK",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eDESTADDRREQ",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eDIRTY",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eDOM",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eDQUOT",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eEXIST",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eFAULT",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eFBIG",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eFTYPE",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eHOSTDOWN",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eHOSTUNREACH",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eIDRM",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eILSEQ",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eINPROGRESS",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eINTR",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eINVAL",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eIO",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eISCONN",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eISDIR",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eLOOP",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eMFILE",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eMLINK",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eMSGSIZE",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eMULTIHOP",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNAMETOOLONG",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNETDOWN",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNETRESET",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNETUNREACH",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNFILE",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOBUFS",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNODATA",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNODEV",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOENT",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOEXEC",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOLCK",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOLINK",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOMEM",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOMSG",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNONET",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOPROTOOPT",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOSPC",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOSR",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOSTR",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOSYS",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOTBLK",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOTCONN",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOTDIR",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOTEMPTY",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOTSOCK",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOTSUP",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNOTTY",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eNXIO",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eOK",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eOPNOTSUPP",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "ePERM",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "ePFNOSUPPORT",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "ePIPE",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "ePROCLIM",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "ePROCUNAVAIL",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "ePROGMISMATCH",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "ePROGUNAVAIL",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "ePROTO",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "ePROTONOSUPPORT",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "ePROTOTYPE",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eRANGE",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eREMCHG",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eREMOTE",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eROFS",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eRPCMISMATCH",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eRREMOTE",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eSHUTDOWN",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eSOCKTNOSUPPORT",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eSPIPE",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eSRCH",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eSRMNT",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eSTALE",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eTIME",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eTIMEDOUT",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eTOOMANYREFS",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eTXTBSY",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eUSERS",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eWOULDBLOCK",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "eXDEV",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "errnoToIOError",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "getErrno",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "isValidErrno",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "resetErrno",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrno",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoIf",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoIfMinus1",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoIfMinus1Retry",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoIfMinus1RetryMayBlock",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoIfMinus1RetryMayBlock_",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoIfMinus1Retry_",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoIfMinus1_",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoIfNull",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoIfNullRetry",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoIfNullRetryMayBlock",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoIfRetry",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoIfRetryMayBlock",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoIfRetryMayBlock_",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoIfRetry_",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoIf_",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoPath",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoPathIf",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoPathIfMinus1",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoPathIfMinus1_",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoPathIfNull",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "throwErrnoPathIf_",
        "module": "Foreign.C.Error",
        "entity": "value"
    },
    {
        "name": "Errno",
        "module": "Foreign.C.Error",
        "type": "Errno",
        "entity": "constructor"
    },
    {
        "name": "Errno",
        "module": "Foreign.C.Error",
        "entity": "newtype"
    }
]
